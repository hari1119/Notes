# -*- coding: utf-8 -*-
{
    'name': "Sale Customization",

    'summary': "Sale Order Automation",

    'description': """
        Sale order automated delivery, invoice and backorder process.
    """,

    'author': "Hari",

    'website': "https://hari1119.github.io/",

    'category': 'Customizations',

    'version': '0.1',

    'depends': ['base','sale_stock'],
}

