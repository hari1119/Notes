from odoo import _, models 
from odoo.exceptions import UserError

class SaleOrder(models.Model):
    _inherit = "sale.order"

    def action_confirm(self):
        res = super(SaleOrder, self.with_context(default_immediate_transfer=True)).action_confirm()
        for order in self:
            if order.picking_ids:                 
                for picking in self.picking_ids:
                    for move in picking.move_ids:
                        if move.product_id.qty_available <= 0 and move.product_id.is_storable:
                            raise UserError(_(f"No stock available for the product : {move.product_id.name}"))
                        elif move.product_id.qty_available < move.product_uom_qty:
                            # Backorder Process
                            move._create_backorder()
                        else:
                            move.quantity = move.product_id.qty_available
                    #Stock Picking Process
                    picking._autoconfirm_picking()
                    #Stock Validation Process
                    picking.button_validate()
                   
                    for mv_line in picking.move_ids.mapped('move_line_ids'):
                        mv_line.quantity = mv_line.quantity_product_uom
                     
                    picking._action_done()

            if not order.invoice_ids: 
                # Invoice Creation Process            
                order._create_invoices()
            if order.invoice_ids:                
                for invoice in order.invoice_ids:
                    # Invoice Post Process
                    invoice.action_post()
        return res  
