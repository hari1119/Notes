# -*- coding: utf-8 -*-
{
    'name': "Expense Extended",

    'summary': "Expense Second Approval Access",

    'description': """
          Enabled expense second approval access.
    """,

    'author': "Hari",
    'website': "https://hari1119.github.io/",
    'category': 'Customizations',
    'version': '0.1',

    'depends': ['base', 'hr', 'hr_expense'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/hr_employee_views.xml',
        'views/hr_expense_views.xml'
    ],
}

