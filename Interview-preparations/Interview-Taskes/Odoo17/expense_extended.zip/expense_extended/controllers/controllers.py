# -*- coding: utf-8 -*-
# from odoo import http


# class ExpenseExtended(http.Controller):
#     @http.route('/expense_extended/expense_extended', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/expense_extended/expense_extended/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('expense_extended.listing', {
#             'root': '/expense_extended/expense_extended',
#             'objects': http.request.env['expense_extended.expense_extended'].search([]),
#         })

#     @http.route('/expense_extended/expense_extended/objects/<model("expense_extended.expense_extended"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('expense_extended.object', {
#             'object': obj
#         })

