
from odoo import models, fields, api


class HrEmployeePrivate(models.Model):
    _inherit = "hr.employee"
    
    second_approval_user_id = fields.Many2one('res.users', 'Second Approval User', ondelete='restrict')
    

