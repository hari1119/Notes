
from odoo import models, fields, api


class HrExpense(models.Model):
    _inherit = "hr.expense.sheet"

    second_approval_user_id = fields.Many2one('res.users', 'Second Approval User', ondelete='restrict', tracking=True)

    state = fields.Selection(
        selection=[
            ('draft', 'To Submit'),
            ('submit', 'Submitted'),
            ('approve', 'Approved'),
            ('second_approved', 'Second Approved'),            
            ('post', 'Posted'),
            ('done', 'Done'),
            ('cancel', 'Refused'),
            ('rejected', 'Rejected')
            
        ],
        string="Status",
        compute='_compute_state', store=True, readonly=True,
        index=True,
        required=True,
        default='draft',
        tracking=True,
        copy=False,
    )

    def action_second_approve(self):
        self.second_approval_user_id = self.env.uid
        self.state = 'second_approved'

    def action_reject(self):
        self.state = 'rejected'
        
        
